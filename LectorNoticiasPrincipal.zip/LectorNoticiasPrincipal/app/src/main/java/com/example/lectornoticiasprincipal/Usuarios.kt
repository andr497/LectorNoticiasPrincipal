package com.example.lectornoticiasprincipal

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey

@Entity(tableName = "Usuarios")
class Usuarios(@PrimaryKey(autoGenerate = true) @ColumnInfo(name="user") val id: String)
{
    @ColumnInfo(name = "nombre") var nombre:String? = null
    @ColumnInfo(name = "apellido") var apellido:String? = null
    @ColumnInfo(name = "user") var user:String? = null
    @ColumnInfo(name = "pass") var pass:String? = null
}