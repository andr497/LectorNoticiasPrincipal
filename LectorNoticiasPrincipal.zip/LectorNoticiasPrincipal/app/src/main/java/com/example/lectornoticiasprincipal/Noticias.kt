package com.example.lectornoticiasprincipal

data class Noticias(
    val titulo:String,
    val descripcion:String,
    val fecha:String,
    val imagen:String,
    val autor:String
){}