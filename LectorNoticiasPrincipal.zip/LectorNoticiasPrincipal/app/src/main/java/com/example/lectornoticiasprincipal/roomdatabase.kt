package com.example.lectornoticiasprincipal

import android.arch.persistence.room.Database
import android.arch.persistence.room.Room
import android.arch.persistence.room.RoomDatabase
import android.content.Context

@Database(entities = [Usuarios::class], version = 1)
public abstract class room : RoomDatabase(){
    abstract fun dao():Daousuario

    companion object{
        @Volatile
        private var  INSTANCE: room? = null

        fun getDatabase(context: Context):room {
            val tempInstance= INSTANCE
            if(tempInstance != null){
                return  tempInstance
            }
            synchronized(room::class){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    room::class.java,
                    "db_noticias"
                ).build()
                INSTANCE = instance
                return instance
            }
        }
    }
}