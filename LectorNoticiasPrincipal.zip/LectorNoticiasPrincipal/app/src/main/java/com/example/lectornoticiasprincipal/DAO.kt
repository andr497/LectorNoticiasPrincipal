package com.example.lectornoticiasprincipal

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query

@Dao
interface Daousuario{
    @Query("select * from Usuarios")
    fun getusuarios(): List<Usuarios>

    @Insert
    suspend fun insert(Usuarios: Usuarios)

    @Query("delete from Usuarios")
    fun deleteAll()
}