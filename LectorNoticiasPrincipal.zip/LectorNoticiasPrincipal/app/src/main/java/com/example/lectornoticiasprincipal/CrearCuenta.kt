package com.example.lectornoticiasprincipal

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class CrearCuenta : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crear_cuenta)

        var listausuarios=ArrayList<Usuarios>()
        val BD = room.getDatabase(this)

        GlobalScope
    }
}
